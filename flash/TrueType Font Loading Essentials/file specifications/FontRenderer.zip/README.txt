There are 2 Flex Builder projects:
 - FontRenderer.zip
 - Graphics2D.zip

extract both and import in flex builder workspace. 
Open the FontRenderer project properties and in the "Flex Build Path" select the "Library Path" tab and click on "Add Project". In the project chooser dialog select the "Graphics2D" project.
